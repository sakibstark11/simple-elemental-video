import cv2
import face_recognition
import numpy as np


def detect_bounding_box(frame):
    print('detecting bounding box')
    rgb_frame = frame[:, :, ::-1]
    face_locations = face_recognition.face_locations(rgb_frame)
    for top, right, bottom, left in face_locations:
        cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 255), 2)
        face_image = frame[top:bottom, left:right]
        blurred_face = cv2.blur(face_image, (99, 99))
        frame[top:bottom, left:right] = blurred_face
    return face_locations


def process_video_stream():
    video_capture = cv2.VideoCapture(0)

    while True:
        result, frame = video_capture.read()
        if result is False:
            break
        small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
        faces = detect_bounding_box(small_frame)

        cv2.imshow('Video', small_frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    video_capture.release()
    cv2.destroyAllWindows()


process_video_stream()
